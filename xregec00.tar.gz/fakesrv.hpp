/*
    ISA course project, 2015/2016
    Variant: FTP/SSH Honeypot
    Author: Dominika Regeciova, xregec00
*/

#ifndef __fakesrv_defined__
#define __fakesrv_defined__

#include <iostream>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
#include "logging.hpp"
#include "ftp.hpp"
#include "ssh.hpp"

using namespace std;

#endif